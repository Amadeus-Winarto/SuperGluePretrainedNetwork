class SuperGlue(Module):
  __parameters__ = ["bin_score", ]
  __buffers__ = []
  bin_score : Tensor
  training : bool
  _is_full_backward_hook : Optional[bool]
  descriptor_dim : int
  weights : str
  keypoint_encoder : List[int]
  GNN_layers : List[str]
  sinkhorn_iterations : int
  match_threshold : float
  kenc : __torch__.models.SuperGluePretrainedNetwork.models.superglue.KeypointEncoder
  gnn : __torch__.models.SuperGluePretrainedNetwork.models.superglue.AttentionalGNN
  final_proj : __torch__.torch.nn.modules.conv.___torch_mangle_14.Conv1d
  def forward(self: __torch__.models.SuperGluePretrainedNetwork.models.superglue.SuperGlue,
    data: Dict[str, Tensor]) -> Dict[str, Tensor]:
    _0 = __torch__.models.SuperGluePretrainedNetwork.models.superglue.normalize_keypoints
    _1 = __torch__.models.SuperGluePretrainedNetwork.models.superglue.log_optimal_transport
    _2 = __torch__.models.SuperGluePretrainedNetwork.models.superglue.arange_like
    desc0 = data["descriptors0"]
    desc1 = data["descriptors1"]
    kpts0 = data["keypoints0"]
    kpts1 = data["keypoints1"]
    if torch.eq((torch.size(kpts0))[1], 0):
      _3 = True
    else:
      _4 = torch.eq((torch.size(kpts1))[1], 0)
      _3 = _4
    if _3:
      shape0 = torch.slice(torch.size(kpts0), None, -1)
      shape1 = torch.slice(torch.size(kpts1), None, -1)
      _6 = torch.new_full(kpts0, shape0, -1, dtype=3)
      _7 = torch.new_full(kpts1, shape1, -1, dtype=3)
      _8 = {"matches0": _6, "matches1": _7, "matching_scores0": torch.new_zeros(kpts0, shape0), "matching_scores1": torch.new_zeros(kpts1, shape1)}
      _5 = _8
    else:
      kpts00 = _0(kpts0, torch.size(data["image0"]), )
      kpts10 = _0(kpts1, torch.size(data["image1"]), )
      kenc = self.kenc
      _9 = (kenc).forward(kpts00, data["scores0"], )
      desc00 = torch.add(desc0, _9)
      kenc0 = self.kenc
      _10 = (kenc0).forward(kpts10, data["scores1"], )
      desc10 = torch.add(desc1, _10)
      gnn = self.gnn
      desc01, desc11, = (gnn).forward(desc00, desc10, )
      final_proj = self.final_proj
      mdesc0 = (final_proj).forward(desc01, )
      final_proj0 = self.final_proj
      mdesc1 = (final_proj0).forward(desc11, )
      scores = torch.einsum("bdn,bdm->bnm", [mdesc0, mdesc1])
      descriptor_dim = self.descriptor_dim
      scores0 = torch.div(scores, torch.pow(descriptor_dim, 0.5))
      bin_score = self.bin_score
      sinkhorn_iterations = self.sinkhorn_iterations
      scores1 = _1(scores0, bin_score, sinkhorn_iterations, )
      _11 = torch.slice(torch.slice(scores1), 1, None, -1)
      _12, _13 = torch.max(torch.slice(_11, 2, None, -1), 2)
      _14 = torch.slice(torch.slice(scores1), 1, None, -1)
      _15, _16 = torch.max(torch.slice(_14, 2, None, -1), 1)
      mutual0 = torch.eq(torch.unsqueeze(_2(_13, 1, ), 0), torch.gather(_16, 1, _13))
      mutual1 = torch.eq(torch.unsqueeze(_2(_16, 1, ), 0), torch.gather(_13, 1, _16))
      zero = torch.to(torch.tensor(0), scores1)
      mscores0 = torch.where(mutual0, torch.exp(_12), zero)
      mscores1 = torch.where(mutual1, torch.gather(mscores0, 1, _16), zero)
      match_threshold = self.match_threshold
      _17 = torch.gt(mscores0, match_threshold)
      valid0 = torch.__and__(mutual0, _17)
      valid1 = torch.__and__(mutual1, torch.gather(valid0, 1, _16))
      indices0 = torch.where(valid0, _13, torch.to(torch.tensor(-1), _13))
      indices1 = torch.where(valid1, _16, torch.to(torch.tensor(-1), _16))
      _18 = {"matches0": indices0, "matches1": indices1, "matching_scores0": mscores0, "matching_scores1": mscores1}
      _5 = _18
    return _5
class KeypointEncoder(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  encoder : __torch__.torch.nn.modules.container.Sequential
  def forward(self: __torch__.models.SuperGluePretrainedNetwork.models.superglue.KeypointEncoder,
    kpts: Tensor,
    scores: Tensor) -> Tensor:
    inputs = [torch.transpose(kpts, 1, 2), torch.unsqueeze(scores, 1)]
    encoder = self.encoder
    _19 = (encoder).forward(torch.cat(inputs, 1), )
    return _19
class AttentionalGNN(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  names : List[str]
  layers : __torch__.torch.nn.modules.container.___torch_mangle_20.ModuleList
  def forward(self: __torch__.models.SuperGluePretrainedNetwork.models.superglue.AttentionalGNN,
    desc0: Tensor,
    desc1: Tensor) -> Tuple[Tensor, Tensor]:
    layers = self.layers
    _0 = getattr(layers, "0")
    _1 = getattr(layers, "1")
    _2 = getattr(layers, "2")
    _3 = getattr(layers, "3")
    _4 = getattr(layers, "4")
    _5 = getattr(layers, "5")
    _6 = getattr(layers, "6")
    _7 = getattr(layers, "7")
    _8 = getattr(layers, "8")
    _9 = getattr(layers, "9")
    _10 = getattr(layers, "10")
    _11 = getattr(layers, "11")
    _12 = getattr(layers, "12")
    _13 = getattr(layers, "13")
    _14 = getattr(layers, "14")
    _15 = getattr(layers, "15")
    _16 = getattr(layers, "16")
    _17 = getattr(layers, "17")
    names = self.names
    if torch.eq(names[0], "cross"):
      src0, src1 = desc1, desc0
    else:
      src0, src1 = desc0, desc1
    delta0 = (_0).forward(desc0, src0, )
    delta1 = (_0).forward(desc1, src1, )
    desc02 = torch.add(desc0, delta0)
    desc12 = torch.add(desc1, delta1)
    names0 = self.names
    if torch.eq(names0[1], "cross"):
      src00, src10 = desc12, desc02
    else:
      src00, src10 = desc02, desc12
    delta00 = (_1).forward(desc02, src00, )
    delta10 = (_1).forward(desc12, src10, )
    desc03 = torch.add(desc02, delta00)
    desc13 = torch.add(desc12, delta10)
    names1 = self.names
    if torch.eq(names1[2], "cross"):
      src01, src11 = desc13, desc03
    else:
      src01, src11 = desc03, desc13
    delta01 = (_2).forward(desc03, src01, )
    delta11 = (_2).forward(desc13, src11, )
    desc04 = torch.add(desc03, delta01)
    desc14 = torch.add(desc13, delta11)
    names2 = self.names
    if torch.eq(names2[3], "cross"):
      src02, src12 = desc14, desc04
    else:
      src02, src12 = desc04, desc14
    delta02 = (_3).forward(desc04, src02, )
    delta12 = (_3).forward(desc14, src12, )
    desc05 = torch.add(desc04, delta02)
    desc15 = torch.add(desc14, delta12)
    names3 = self.names
    if torch.eq(names3[4], "cross"):
      src03, src13 = desc15, desc05
    else:
      src03, src13 = desc05, desc15
    delta03 = (_4).forward(desc05, src03, )
    delta13 = (_4).forward(desc15, src13, )
    desc06 = torch.add(desc05, delta03)
    desc16 = torch.add(desc15, delta13)
    names4 = self.names
    if torch.eq(names4[5], "cross"):
      src04, src14 = desc16, desc06
    else:
      src04, src14 = desc06, desc16
    delta04 = (_5).forward(desc06, src04, )
    delta14 = (_5).forward(desc16, src14, )
    desc07 = torch.add(desc06, delta04)
    desc17 = torch.add(desc16, delta14)
    names5 = self.names
    if torch.eq(names5[6], "cross"):
      src05, src15 = desc17, desc07
    else:
      src05, src15 = desc07, desc17
    delta05 = (_6).forward(desc07, src05, )
    delta15 = (_6).forward(desc17, src15, )
    desc08 = torch.add(desc07, delta05)
    desc18 = torch.add(desc17, delta15)
    names6 = self.names
    if torch.eq(names6[7], "cross"):
      src06, src16 = desc18, desc08
    else:
      src06, src16 = desc08, desc18
    delta06 = (_7).forward(desc08, src06, )
    delta16 = (_7).forward(desc18, src16, )
    desc09 = torch.add(desc08, delta06)
    desc19 = torch.add(desc18, delta16)
    names7 = self.names
    if torch.eq(names7[8], "cross"):
      src07, src17 = desc19, desc09
    else:
      src07, src17 = desc09, desc19
    delta07 = (_8).forward(desc09, src07, )
    delta17 = (_8).forward(desc19, src17, )
    desc010 = torch.add(desc09, delta07)
    desc110 = torch.add(desc19, delta17)
    names8 = self.names
    if torch.eq(names8[9], "cross"):
      src08, src18 = desc110, desc010
    else:
      src08, src18 = desc010, desc110
    delta08 = (_9).forward(desc010, src08, )
    delta18 = (_9).forward(desc110, src18, )
    desc011 = torch.add(desc010, delta08)
    desc111 = torch.add(desc110, delta18)
    names9 = self.names
    if torch.eq(names9[10], "cross"):
      src09, src19 = desc111, desc011
    else:
      src09, src19 = desc011, desc111
    delta09 = (_10).forward(desc011, src09, )
    delta19 = (_10).forward(desc111, src19, )
    desc012 = torch.add(desc011, delta09)
    desc112 = torch.add(desc111, delta19)
    names10 = self.names
    if torch.eq(names10[11], "cross"):
      src010, src110 = desc112, desc012
    else:
      src010, src110 = desc012, desc112
    delta010 = (_11).forward(desc012, src010, )
    delta110 = (_11).forward(desc112, src110, )
    desc013 = torch.add(desc012, delta010)
    desc113 = torch.add(desc112, delta110)
    names11 = self.names
    if torch.eq(names11[12], "cross"):
      src011, src111 = desc113, desc013
    else:
      src011, src111 = desc013, desc113
    delta011 = (_12).forward(desc013, src011, )
    delta111 = (_12).forward(desc113, src111, )
    desc014 = torch.add(desc013, delta011)
    desc114 = torch.add(desc113, delta111)
    names12 = self.names
    if torch.eq(names12[13], "cross"):
      src012, src112 = desc114, desc014
    else:
      src012, src112 = desc014, desc114
    delta012 = (_13).forward(desc014, src012, )
    delta112 = (_13).forward(desc114, src112, )
    desc015 = torch.add(desc014, delta012)
    desc115 = torch.add(desc114, delta112)
    names13 = self.names
    if torch.eq(names13[14], "cross"):
      src013, src113 = desc115, desc015
    else:
      src013, src113 = desc015, desc115
    delta013 = (_14).forward(desc015, src013, )
    delta113 = (_14).forward(desc115, src113, )
    desc016 = torch.add(desc015, delta013)
    desc116 = torch.add(desc115, delta113)
    names14 = self.names
    if torch.eq(names14[15], "cross"):
      src014, src114 = desc116, desc016
    else:
      src014, src114 = desc016, desc116
    delta014 = (_15).forward(desc016, src014, )
    delta114 = (_15).forward(desc116, src114, )
    desc017 = torch.add(desc016, delta014)
    desc117 = torch.add(desc116, delta114)
    names15 = self.names
    if torch.eq(names15[16], "cross"):
      src015, src115 = desc117, desc017
    else:
      src015, src115 = desc017, desc117
    delta015 = (_16).forward(desc017, src015, )
    delta115 = (_16).forward(desc117, src115, )
    desc018 = torch.add(desc017, delta015)
    desc118 = torch.add(desc117, delta115)
    names16 = self.names
    if torch.eq(names16[17], "cross"):
      src016, src116 = desc118, desc018
    else:
      src016, src116 = desc018, desc118
    delta016 = (_17).forward(desc018, src016, )
    delta116 = (_17).forward(desc118, src116, )
    desc019 = torch.add(desc018, delta016)
    desc119 = torch.add(desc118, delta116)
    return (desc019, desc119)
class AttentionalPropagation(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  attn : __torch__.models.SuperGluePretrainedNetwork.models.superglue.MultiHeadedAttention
  mlp : __torch__.torch.nn.modules.container.___torch_mangle_18.Sequential
  def forward(self: __torch__.models.SuperGluePretrainedNetwork.models.superglue.AttentionalPropagation,
    x: Tensor,
    source: Tensor) -> Tensor:
    attn = self.attn
    message = (attn).forward(x, source, source, )
    mlp = self.mlp
    _20 = (mlp).forward(torch.cat([x, message], 1), )
    return _20
class MultiHeadedAttention(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : NoneType
  dim : int
  num_heads : int
  prob : List[Tensor]
  merge : __torch__.torch.nn.modules.conv.___torch_mangle_14.Conv1d
  proj : __torch__.torch.nn.modules.container.ModuleList
  def forward(self: __torch__.models.SuperGluePretrainedNetwork.models.superglue.MultiHeadedAttention,
    query: Tensor,
    key: Tensor,
    value: Tensor) -> Tensor:
    _21 = __torch__.models.SuperGluePretrainedNetwork.models.superglue.attention
    batch_dim = torch.size(query, 0)
    _22 = annotate(List[Tensor], [])
    proj = self.proj
    _0 = getattr(proj, "0")
    _1 = getattr(proj, "1")
    _2 = getattr(proj, "2")
    _23 = (_0).forward(query, )
    dim = self.dim
    num_heads = self.num_heads
    _24 = torch.view(_23, [batch_dim, dim, num_heads, -1])
    _25 = torch.append(_22, _24)
    _26 = (_1).forward(key, )
    dim0 = self.dim
    num_heads0 = self.num_heads
    _27 = torch.view(_26, [batch_dim, dim0, num_heads0, -1])
    _28 = torch.append(_22, _27)
    _29 = (_2).forward(value, )
    dim1 = self.dim
    num_heads1 = self.num_heads
    _30 = torch.view(_29, [batch_dim, dim1, num_heads1, -1])
    _31 = torch.append(_22, _30)
    query0, key0, value0, = _22
    x, _32, = _21(query0, key0, value0, )
    merge = self.merge
    _33 = torch.contiguous(x)
    dim2 = self.dim
    num_heads2 = self.num_heads
    _34 = [batch_dim, torch.mul(dim2, num_heads2), -1]
    _35 = (merge).forward(torch.view(_33, _34), )
    return _35
def normalize_keypoints(kpts: Tensor,
    image_shape: List[int]) -> Tensor:
  _36, _37, height, width, = image_shape
  size = torch.tensor([[width, height]], dtype=6, device=ops.prim.device(kpts))
  center = torch.div(size, 2)
  _38, _39 = torch.max(size, 1, True)
  scaling = torch.mul(_38, 0.69999999999999996)
  _40 = torch.unsqueeze(torch.slice(center), 1)
  _41 = torch.sub(kpts, torch.slice(_40, 2))
  _42 = torch.unsqueeze(torch.slice(scaling), 1)
  return torch.div(_41, torch.slice(_42, 2))
def log_optimal_transport(scores: Tensor,
    alpha: Tensor,
    iters: int) -> Tensor:
  _43 = __torch__.models.SuperGluePretrainedNetwork.models.superglue.log_sinkhorn_iterations
  b, m, n, = torch.size(scores)
  ms = torch.to(torch.tensor(m), scores)
  ns = torch.to(torch.tensor(n), scores)
  bins0 = torch.expand(alpha, [b, m, 1])
  bins1 = torch.expand(alpha, [b, 1, n])
  alpha0 = torch.expand(alpha, [b, 1, 1])
  _44 = [torch.cat([scores, bins0], -1), torch.cat([bins1, alpha0], -1)]
  couplings = torch.cat(_44, 1)
  norm = torch.neg(torch.log(torch.add(ms, ns)))
  _45 = torch.expand(norm, [m])
  _46 = torch.add(torch.unsqueeze(torch.log(ns), 0), norm)
  log_mu = torch.cat([_45, _46])
  _47 = torch.expand(norm, [n])
  _48 = torch.add(torch.unsqueeze(torch.log(ms), 0), norm)
  log_nu = torch.cat([_47, _48])
  log_mu0 = torch.expand(torch.unsqueeze(log_mu, 0), [b, -1])
  log_nu0 = torch.expand(torch.unsqueeze(log_nu, 0), [b, -1])
  Z = _43(couplings, log_mu0, log_nu0, iters, )
  return torch.sub(Z, norm)
def arange_like(x: Tensor,
    dim: int) -> Tensor:
  _49 = (torch.size(x))[dim]
  _50 = ops.prim.dtype(x)
  _51 = ops.prim.device(x)
  _52 = torch.ones([_49], dtype=_50, layout=None, device=_51)
  return torch.sub(torch.cumsum(_52, 0), 1)
def attention(query: Tensor,
    key: Tensor,
    value: Tensor) -> Tuple[Tensor, Tensor]:
  dim = (torch.size(query))[1]
  _53 = torch.einsum("bdhn,bdhm->bhnm", [query, key])
  scores = torch.div(_53, torch.pow(dim, 0.5))
  prob = __torch__.torch.nn.functional.softmax(scores, -1, 3, None, )
  _54 = torch.einsum("bhnm,bdhm->bdhn", [prob, value])
  return (_54, prob)
def log_sinkhorn_iterations(Z: Tensor,
    log_mu: Tensor,
    log_nu: Tensor,
    iters: int) -> Tensor:
  u = torch.zeros_like(log_mu)
  v = torch.zeros_like(log_nu)
  u0 = u
  v0 = v
  for _55 in range(iters):
    _56 = torch.add(Z, torch.unsqueeze(v0, 1))
    u1 = torch.sub(log_mu, torch.logsumexp(_56, [2]))
    _57 = torch.add(Z, torch.unsqueeze(u1, 2))
    v1 = torch.sub(log_nu, torch.logsumexp(_57, [1]))
    u0, v0 = u1, v1
  _58 = torch.add(torch.add(Z, torch.unsqueeze(u0, 2)), torch.unsqueeze(v0, 1))
  return _58
