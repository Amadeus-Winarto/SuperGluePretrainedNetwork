class AttentionalPropagation(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : NoneType
  attn : __torch__.models.SuperGluePretrainedNetwork.models.superglue.MultiHeadedAttention
  mlp : __torch__.torch.nn.modules.container.___torch_mangle_18.Sequential
  def forward(self: __torch__.models.SuperGluePretrainedNetwork.models.superglue.___torch_mangle_19.AttentionalPropagation,
    x: Tensor,
    source: Tensor) -> Tensor:
    attn = self.attn
    message = (attn).forward(x, source, source, )
    mlp = self.mlp
    _0 = (mlp).forward(torch.cat([x, message], 1), )
    return _0
