class ModuleList(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : NoneType
  __annotations__["0"] = __torch__.models.SuperGluePretrainedNetwork.models.superglue.AttentionalPropagation
  __annotations__["1"] = __torch__.models.SuperGluePretrainedNetwork.models.superglue.___torch_mangle_19.AttentionalPropagation
  __annotations__["2"] = __torch__.models.SuperGluePretrainedNetwork.models.superglue.___torch_mangle_19.AttentionalPropagation
  __annotations__["3"] = __torch__.models.SuperGluePretrainedNetwork.models.superglue.___torch_mangle_19.AttentionalPropagation
  __annotations__["4"] = __torch__.models.SuperGluePretrainedNetwork.models.superglue.___torch_mangle_19.AttentionalPropagation
  __annotations__["5"] = __torch__.models.SuperGluePretrainedNetwork.models.superglue.___torch_mangle_19.AttentionalPropagation
  __annotations__["6"] = __torch__.models.SuperGluePretrainedNetwork.models.superglue.___torch_mangle_19.AttentionalPropagation
  __annotations__["7"] = __torch__.models.SuperGluePretrainedNetwork.models.superglue.___torch_mangle_19.AttentionalPropagation
  __annotations__["8"] = __torch__.models.SuperGluePretrainedNetwork.models.superglue.___torch_mangle_19.AttentionalPropagation
  __annotations__["9"] = __torch__.models.SuperGluePretrainedNetwork.models.superglue.___torch_mangle_19.AttentionalPropagation
  __annotations__["10"] = __torch__.models.SuperGluePretrainedNetwork.models.superglue.___torch_mangle_19.AttentionalPropagation
  __annotations__["11"] = __torch__.models.SuperGluePretrainedNetwork.models.superglue.___torch_mangle_19.AttentionalPropagation
  __annotations__["12"] = __torch__.models.SuperGluePretrainedNetwork.models.superglue.___torch_mangle_19.AttentionalPropagation
  __annotations__["13"] = __torch__.models.SuperGluePretrainedNetwork.models.superglue.___torch_mangle_19.AttentionalPropagation
  __annotations__["14"] = __torch__.models.SuperGluePretrainedNetwork.models.superglue.___torch_mangle_19.AttentionalPropagation
  __annotations__["15"] = __torch__.models.SuperGluePretrainedNetwork.models.superglue.___torch_mangle_19.AttentionalPropagation
  __annotations__["16"] = __torch__.models.SuperGluePretrainedNetwork.models.superglue.___torch_mangle_19.AttentionalPropagation
  __annotations__["17"] = __torch__.models.SuperGluePretrainedNetwork.models.superglue.___torch_mangle_19.AttentionalPropagation
  def __len__(self: __torch__.torch.nn.modules.container.___torch_mangle_20.ModuleList) -> int:
    return 18
