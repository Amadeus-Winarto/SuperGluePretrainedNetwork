class SuperPoint(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  descriptor_dim : int
  nms_radius : int
  keypoint_threshold : float
  max_keypoints : int
  remove_borders : int
  relu : __torch__.torch.nn.modules.activation.ReLU
  pool : __torch__.torch.nn.modules.pooling.MaxPool2d
  conv1a : __torch__.torch.nn.modules.conv.Conv2d
  conv1b : __torch__.torch.nn.modules.conv.___torch_mangle_0.Conv2d
  conv2a : __torch__.torch.nn.modules.conv.___torch_mangle_0.Conv2d
  conv2b : __torch__.torch.nn.modules.conv.___torch_mangle_0.Conv2d
  conv3a : __torch__.torch.nn.modules.conv.___torch_mangle_1.Conv2d
  conv3b : __torch__.torch.nn.modules.conv.___torch_mangle_2.Conv2d
  conv4a : __torch__.torch.nn.modules.conv.___torch_mangle_2.Conv2d
  conv4b : __torch__.torch.nn.modules.conv.___torch_mangle_2.Conv2d
  convPa : __torch__.torch.nn.modules.conv.___torch_mangle_3.Conv2d
  convPb : __torch__.torch.nn.modules.conv.___torch_mangle_4.Conv2d
  convDa : __torch__.torch.nn.modules.conv.___torch_mangle_3.Conv2d
  convDb : __torch__.torch.nn.modules.conv.___torch_mangle_5.Conv2d
  def forward(self: __torch__.models.SuperGluePretrainedNetwork.models.superpoint.SuperPoint,
    image: Tensor) -> Dict[str, List[Tensor]]:
    _0 = __torch__.torch.nn.functional.softmax
    _1 = __torch__.models.SuperGluePretrainedNetwork.models.superpoint.simple_nms
    _2 = __torch__.torch.nn.functional.normalize
    _3 = __torch__.models.SuperGluePretrainedNetwork.models.superpoint.remove_borders
    _4 = __torch__.models.SuperGluePretrainedNetwork.models.superpoint.top_k_keypoints
    _5 = __torch__.models.SuperGluePretrainedNetwork.models.superpoint.sample_descriptors
    relu = self.relu
    conv1a = self.conv1a
    x = (relu).forward((conv1a).forward(image, ), )
    relu0 = self.relu
    conv1b = self.conv1b
    x0 = (relu0).forward((conv1b).forward(x, ), )
    pool = self.pool
    x1 = (pool).forward(x0, )
    relu1 = self.relu
    conv2a = self.conv2a
    x2 = (relu1).forward((conv2a).forward(x1, ), )
    relu2 = self.relu
    conv2b = self.conv2b
    x3 = (relu2).forward((conv2b).forward(x2, ), )
    pool0 = self.pool
    x4 = (pool0).forward(x3, )
    relu3 = self.relu
    conv3a = self.conv3a
    x5 = (relu3).forward((conv3a).forward(x4, ), )
    relu4 = self.relu
    conv3b = self.conv3b
    x6 = (relu4).forward((conv3b).forward(x5, ), )
    pool1 = self.pool
    x7 = (pool1).forward(x6, )
    relu5 = self.relu
    conv4a = self.conv4a
    x8 = (relu5).forward((conv4a).forward(x7, ), )
    relu6 = self.relu
    conv4b = self.conv4b
    x9 = (relu6).forward((conv4b).forward(x8, ), )
    relu7 = self.relu
    convPa = self.convPa
    cPa = (relu7).forward((convPa).forward(x9, ), )
    convPb = self.convPb
    scores = (convPb).forward(cPa, )
    _6 = torch.slice(_0(scores, 1, 3, None, ))
    scores0 = torch.slice(_6, 1, None, -1)
    b, _7, h, w, = torch.size(scores0)
    _8 = torch.permute(scores0, [0, 2, 3, 1])
    scores1 = torch.reshape(_8, [b, h, w, 8, 8])
    _9 = torch.permute(scores1, [0, 1, 3, 2, 4])
    _10 = [b, torch.mul(h, 8), torch.mul(w, 8)]
    scores2 = torch.reshape(_9, _10)
    nms_radius = self.nms_radius
    scores3 = _1(scores2, nms_radius, )
    relu8 = self.relu
    convDa = self.convDa
    cDa = (relu8).forward((convDa).forward(x9, ), )
    convDb = self.convDb
    descriptors = (convDb).forward(cDa, )
    descriptors0 = _2(descriptors, 2., 1, 9.9999999999999998e-13, None, )
    keypoints = annotate(List[Tensor], [])
    scores_out = annotate(List[Tensor], [])
    descriptors_out = annotate(List[Tensor], [])
    for i in range(b):
      s = torch.select(scores3, 0, i)
      keypoint_threshold = self.keypoint_threshold
      k = torch.nonzero(torch.gt(s, keypoint_threshold))
      keypoint_threshold0 = self.keypoint_threshold
      _11 = annotate(List[Optional[Tensor]], [torch.gt(s, keypoint_threshold0)])
      s0 = torch.index(s, _11)
      remove_borders = self.remove_borders
      _12 = _3(k, s0, remove_borders, torch.mul(h, 8), torch.mul(w, 8), )
      k0, s1, = _12
      max_keypoints = self.max_keypoints
      if torch.ge(max_keypoints, 0):
        max_keypoints0 = self.max_keypoints
        k2, s3, = _4(k0, s1, max_keypoints0, )
        k1, s2 = k2, s3
      else:
        k1, s2 = k0, s1
      k3 = torch.to(torch.flip(k1, [1]), 6)
      _13 = torch.unsqueeze(k3, 0)
      _14 = torch.unsqueeze(torch.select(descriptors0, 0, i), 0)
      _15 = torch.select(_5(_13, _14, 8, ), 0, 0)
      _16 = torch.append(descriptors_out, _15)
      _17 = torch.append(keypoints, k3)
      _18 = torch.append(scores_out, s2)
    _19 = {"keypoints": keypoints, "scores": scores_out, "descriptors": descriptors_out}
    return _19
def simple_nms(scores: Tensor,
    nms_radius: int) -> Tensor:
  _20 = __torch__.models.SuperGluePretrainedNetwork.models.superpoint.max_pool
  if torch.ge(nms_radius, 0):
    pass
  else:
    ops.prim.RaiseException("AssertionError: ")
  zeros = torch.zeros_like(scores)
  max_mask = torch.eq(scores, _20(scores, nms_radius, ))
  max_mask0 = max_mask
  for _21 in range(2):
    _22 = _20(torch.to(max_mask0, 6), nms_radius, )
    supp_mask = torch.gt(_22, 0)
    supp_scores = torch.where(supp_mask, zeros, scores)
    new_max_mask = torch.eq(supp_scores, _20(supp_scores, nms_radius, ))
    _23 = torch.__and__(new_max_mask, torch.bitwise_not(supp_mask))
    max_mask0 = torch.__or__(max_mask0, _23)
  return torch.where(max_mask0, scores, zeros)
def remove_borders(keypoints: Tensor,
    scores: Tensor,
    border: int,
    height: int,
    width: int) -> Tuple[Tensor, Tensor]:
  _24 = torch.select(torch.slice(keypoints), 1, 0)
  _25 = torch.ge(_24, border)
  _26 = torch.select(torch.slice(keypoints), 1, 0)
  _27 = torch.lt(_26, torch.sub(height, border))
  mask_h = torch.__and__(_25, _27)
  _28 = torch.select(torch.slice(keypoints), 1, 1)
  _29 = torch.ge(_28, border)
  _30 = torch.select(torch.slice(keypoints), 1, 1)
  _31 = torch.lt(_30, torch.sub(width, border))
  mask_w = torch.__and__(_29, _31)
  mask = torch.__and__(mask_h, mask_w)
  _32 = annotate(List[Optional[Tensor]], [mask])
  _33 = torch.index(keypoints, _32)
  _34 = annotate(List[Optional[Tensor]], [mask])
  return (_33, torch.index(scores, _34))
def top_k_keypoints(keypoints: Tensor,
    scores: Tensor,
    k: int) -> Tuple[Tensor, Tensor]:
  if torch.ge(k, torch.len(keypoints)):
    _35 = (keypoints, scores)
  else:
    scores4, indices = torch.topk(scores, k, 0)
    _36 = annotate(List[Optional[Tensor]], [indices])
    _37 = (torch.index(keypoints, _36), scores4)
    _35 = _37
  return _35
def sample_descriptors(keypoints: Tensor,
    descriptors: Tensor,
    s: int=8) -> Tensor:
  _38 = __torch__.torch.nn.functional.grid_sample
  _39 = __torch__.torch.nn.functional.normalize
  b, c, h, w, = torch.size(descriptors)
  keypoints0 = torch.add(torch.sub(keypoints, torch.div(s, 2)), 0.5)
  _40 = torch.sub(torch.mul(w, s), torch.div(s, 2))
  _41 = torch.sub(_40, 0.5)
  _42 = torch.sub(torch.mul(h, s), torch.div(s, 2))
  _43 = torch.tensor([_41, torch.sub(_42, 0.5)])
  _44 = torch.unsqueeze(torch.to(_43, keypoints0), 0)
  keypoints1 = torch.div_(keypoints0, _44)
  keypoints2 = torch.sub(torch.mul(keypoints1, 2), 1)
  descriptors1 = _38(descriptors, torch.view(keypoints2, [b, 1, -1, 2]), "bilinear", "zeros", True, )
  _45 = torch.reshape(descriptors1, [b, c, -1])
  descriptors2 = _39(_45, 2., 1, 9.9999999999999998e-13, None, )
  return descriptors2
def max_pool(x: Tensor,
    nms_radius: int) -> Tensor:
  _46 = __torch__.torch.nn.functional._max_pool2d
  _47 = torch.add(torch.mul(nms_radius, 2), 1)
  _48 = _46(x, [_47, _47], [1, 1], [nms_radius, nms_radius], [1, 1], False, False, )
  return _48
